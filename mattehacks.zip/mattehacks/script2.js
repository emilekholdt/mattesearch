function showId(id) {
  console.log(id.id);
  eksamen.innerHTML = "Dette er eksamen " + id.id;
}
