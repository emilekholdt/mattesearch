let temaer = {
  graf: {oppgaver: ["1h18"], stikkord: ["funksjonen","avgrenser","område","tegn"],score: 0},
  kule: {oppgaver: ["2h18"],stikkord: ["sentrum","kuleflate","radius","likning","tangere","planet"],score: 0},
  rekke: {oppgaver: ["3h18"],stikkord: ["hvor","mye","radius","løpet","prosent","redusere"],score: 0},
  difflikning: {oppgaver: ["4h18"],stikkord: ["proporsjonal","løsning","difflikning","difflikningen","konstant","renner"],score: 0},
  rekke: {oppgaver: ["5h18"],stikkord: ["hvor","mye","radius","løpet","prosent","redusere"],score: 0},
};

function search() {

  let text = document.getElementById('textArea').value;

  for (var i = 0; i < Object.keys(temaer).length; i++) {
    temaer[[Object.keys(temaer)[i]]].score = 0;
  }

  for (var i = 0; i < Object.keys(temaer).length; i++) {
    for (var a = 0; a < temaer[[Object.keys(temaer)[i]]].stikkord.length; a++) {
      if(text.includes(temaer[[Object.keys(temaer)[i]]].stikkord[a])){
      temaer[[Object.keys(temaer)[i]]].score ++;
      console.log("hei");
      }
    }
  }

  let topp = 0;
  let tema;

  for (var i = 0; i < Object.keys(temaer).length; i++) {
    console.log(temaer[Object.keys(temaer)[i]].score);
    if(temaer[Object.keys(temaer)[i]].score > topp){
      tema = temaer[Object.keys(temaer)[i]].oppgaver;
    }
  }
  console.log(tema);
}
